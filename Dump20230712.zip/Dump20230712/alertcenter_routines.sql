-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: alertcenter-rds-dev-01-rds.services.tirescorp.com    Database: alertcenter
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Temporary view structure for view `AlertsView`
--

DROP TABLE IF EXISTS `AlertsView`;
/*!50001 DROP VIEW IF EXISTS `AlertsView`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `AlertsView` AS SELECT 
 1 AS `salesOrderNumber`,
 1 AS `siteId`,
 1 AS `receivingSiteId`,
 1 AS `viewed`,
 1 AS `contacted`,
 1 AS `notes`,
 1 AS `stoFlag`,
 1 AS `alertStatus`,
 1 AS `lastModifiedBy`,
 1 AS `lastModifiedAssociate`,
 1 AS `sourcingDelays`,
 1 AS `paymentStatus`,
 1 AS `label`,
 1 AS `firstName`,
 1 AS `lastName`,
 1 AS `customerType`,
 1 AS `orderSource`,
 1 AS `salesOrderCreateDate`,
 1 AS `orderComment`,
 1 AS `appointmentId`,
 1 AS `appointmentDate`,
 1 AS `phone`,
 1 AS `workPhone`,
 1 AS `homePhone`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `AlertsView`
--

/*!50001 DROP VIEW IF EXISTS `AlertsView`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`acadmin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `AlertsView` AS select `Alerts`.`OrderId` AS `salesOrderNumber`,`Alerts`.`SiteId` AS `siteId`,`Alerts`.`ReceivingSiteId` AS `receivingSiteId`,`Alerts`.`Viewed` AS `viewed`,`Alerts`.`Contacted` AS `contacted`,`Alerts`.`Notes` AS `notes`,`Alerts`.`StoFlag` AS `stoFlag`,`Alerts`.`AlertStatus` AS `alertStatus`,`Alerts`.`LastModified` AS `lastModifiedBy`,`Alerts`.`LastModifiedAssociate` AS `lastModifiedAssociate`,`Alerts`.`SourcingDelays` AS `sourcingDelays`,`Orders`.`PaymentStatus` AS `paymentStatus`,`Orders`.`SourcingStatus` AS `label`,`Orders`.`FirstName` AS `firstName`,`Orders`.`LastName` AS `lastName`,`Orders`.`CustomerType` AS `customerType`,`Orders`.`TransactionType` AS `orderSource`,(case when (`Alerts`.`StoFlag` = 1) then `Orderlineitems`.`POCreateDate` else `Orders`.`CreationDate` end) AS `salesOrderCreateDate`,(case when (`Alerts`.`StoFlag` = 1) then `Alerts`.`Comment` else `Orders`.`Comment` end) AS `orderComment`,`Appointments`.`AppointmentId` AS `appointmentId`,concat(`Appointments`.`AppointmentDate`,' ',`Appointments`.`BackOfficeStartTime`) AS `appointmentDate`,`Orders`.`MobilePhoneNumber` AS `phone`,(case when (`Alerts`.`StoFlag` = 1) then `Alerts`.`WorkPhone` else `Orders`.`WorkPhoneNumber` end) AS `workPhone`,`Orders`.`HomePhoneNumber` AS `homePhone` from (((`Alerts` left join `Orders` on((`Alerts`.`OrderId` = `Orders`.`OrderId`))) left join `Orderlineitems` on((`Orderlineitems`.`PONumber` = `Alerts`.`OrderId`))) left join `Appointments` on((`Alerts`.`OrderId` = `Appointments`.`OrderId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-12 14:39:31
